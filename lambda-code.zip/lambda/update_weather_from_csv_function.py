import json
import urllib.parse
import boto3

print('Loading function')

s3 = boto3.client('s3')
dynamodb_client = boto3.client('dynamodb')

def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event and show its content type
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        # print("CONTENT TYPE: " + response['ContentType'])
        weather_info_list = response['Body'].read().decode('utf-8').splitlines()
        for weather_info in weather_info_list:
            weather_info = weather_info.split(',')
            dynamodb_client.put_item(
                TableName='simple-weather-news-table',
                Item={
                    'Cityid': {
                        'N': weather_info[0],
                    },
                    'CityName': {
                        'S': weather_info[1],
                    },
                    'WeatherId': {
                        'N': weather_info[2],
                    },
                    'WeatherName': {
                        'S': weather_info[3],
                    },
                    'RainfallProbability': {
                        'N': weather_info[4],
                    },
                },
            )
        return response['ContentType']
    except Exception as e:
        # print(e)
        # print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
