import json
import boto3
import random

dynamodb_client = boto3.client('dynamodb')

def lambda_handler(event, context):

    body_dict = json.loads(event['body'])

    city_id = event['pathParameters']['cityId']

    city_name = findCityName(city_id)
    if city_name == 'ERROR':
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid cityId')
        }

    weather_id = body_dict['weatherId']

    if weather_id == 2:
        weather_name = '晴れ'
    elif weather_id == 4:
        weather_name = 'くもり'
    elif weather_id == 12:
        weather_name = 'あめ'

    rainfall_probability = body_dict['rainfallProbability']

    response = dynamodb_client.put_item(
        TableName='simple-weather-news-table',
        Item={
            'Cityid': {
                'N': str(city_id),
            },
            'CityName': {
                'S': city_name,
            },
            'WeatherId': {
                'N': str(weather_id),
            },
            'WeatherName': {
                'S': weather_name,
            },
            'RainfallProbability': {
                'N': str(rainfall_probability),
            },
        },
    )

    return {
        'statusCode': 200,
    }

def findCityName(city_id):
    city_map = {1: '札幌', 13: '東京', 23: '名古屋', 27: '大阪', 40: '博多'}
    return city_map.get(int(city_id), 'ERROR')

    